class Player
  # initialize your player
  def initialize
  end

  # process data for each event from tetris-server
  def process_data(data)
  end

  # This method should return string like left=0, right=0, rotate=0, drop'
  def make_step
  end
end
