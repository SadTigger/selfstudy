To start using this client:

1. Register on codenjoy server.

2. Specify all necessary params in client.rb

3. Run `bundle install`

4. To launch:
```
  ruby client.rb
```
